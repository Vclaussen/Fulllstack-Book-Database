package model;

public class Tester {

	public static void main(String[] args) {
		Book b = new Book(1, "1984", "George Orwell", 200);
		System.out.println(b.getTitle());
		System.out.println(b.getAuthor());
		

	}

}
